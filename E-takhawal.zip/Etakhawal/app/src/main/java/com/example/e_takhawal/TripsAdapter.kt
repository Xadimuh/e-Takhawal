package com.example.e_takhawal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TripsAdapter(private val tripsList: List<Trip>) : RecyclerView.Adapter<TripsAdapter.TripViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TripViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_trip, parent, false)
        return TripViewHolder(view)
    }

    override fun onBindViewHolder(holder: TripViewHolder, position: Int) {
        val trip = tripsList[position]
        holder.bind(trip)
    }

    override fun getItemCount(): Int {
        return tripsList.size
    }

    // ViewHolder pour chaque élément de trajet
    inner class TripViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val sourceText: TextView = itemView.findViewById(R.id.trip_source)
        private val destinationText: TextView = itemView.findViewById(R.id.trip_destination)
        private val dateText: TextView = itemView.findViewById(R.id.trip_date)
        private val timeText: TextView = itemView.findViewById(R.id.trip_time)

        fun bind(trip: Trip) {
            sourceText.text = trip.source
            destinationText.text = trip.destination
            dateText.text = trip.date
            timeText.text = trip.time

            // Vous pouvez ajouter ici des clics ou autres actions pour chaque élément de trajet
        }
    }
}

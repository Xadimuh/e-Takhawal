package com.example.e_takhawal

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*

class AddTripActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_trip)

        // Initialiser Firebase Database et FirebaseAuth
        database = FirebaseDatabase.getInstance().reference
        auth = FirebaseAuth.getInstance()

        // Liaison des vues XML
        val sourceInput: EditText = findViewById(R.id.input_source)
        val destinationInput: EditText = findViewById(R.id.input_destination)
        val dateInput: EditText = findViewById(R.id.input_date)
        val timeInput: EditText = findViewById(R.id.input_time)
        val driverNameInput: EditText = findViewById(R.id.input_driver_name)
        val addTripButton: Button = findViewById(R.id.add_trip_button)

 /*       // Vérification si l'utilisateur est connecté
        val currentUser = auth.currentUser
        if (currentUser == null) {
            // Si l'utilisateur n'est pas connecté, afficher un message et rediriger vers la page de connexion
            Toast.makeText(this, "Vous devez être connecté pour ajouter un trajet", Toast.LENGTH_SHORT).show()
            // Par exemple, redirigez vers la page de connexion :
            val intent = Intent(this, SigninActivity::class.java)
            startActivity(intent)
            finish() // Empêche le retour à cette activité
            return
        } */

        // DatePicker pour le champ Date
        dateInput.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePickerDialog = DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    val formattedDate = "$dayOfMonth/${month + 1}/$year"
                    dateInput.setText(formattedDate)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePickerDialog.show()
        }

        // TimePicker pour le champ Heure
        timeInput.setOnClickListener {
            val calendar = Calendar.getInstance()
            val timePickerDialog = TimePickerDialog(
                this,
                { _, hourOfDay, minute ->
                    val formattedTime = String.format("%02d:%02d", hourOfDay, minute)
                    timeInput.setText(formattedTime)
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            )
            timePickerDialog.show()
        }

        addTripButton.setOnClickListener {
            val driverName = driverNameInput.text.toString().trim()
            val source = sourceInput.text.toString().trim()
            val destination = destinationInput.text.toString().trim()
            val date = dateInput.text.toString().trim()
            val time = timeInput.text.toString().trim()

            // Vérification des champs vides
            if (TextUtils.isEmpty(driverName) || TextUtils.isEmpty(source) || TextUtils.isEmpty(destination) ||
                TextUtils.isEmpty(date) || TextUtils.isEmpty(time)) {
                Toast.makeText(this, "Tous les champs doivent être remplis!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

   /*         // Vérifier que l'utilisateur est connecté
            val currentUser = auth.currentUser
            if (currentUser == null) {
                Toast.makeText(this, "Vous devez être connecté pour ajouter un trajet", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Récupérer le nom de l'utilisateur connecté
            val currentUserName = currentUser.displayName ?: "Inconnu"
*/
            // Générer un ID unique pour le trajet
            val tripId = database.push().key

            if (tripId != null) {
                // Créer un objet Trip
                val trip = Trip(
                    driverName = driverName,
                    source = source,
                    destination = destination,
                    date = date,
                    time = time
                )

                // Ajouter le trajet à Firebase sous "trips"
                database.child("trips").child(tripId).setValue(trip)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Trajet ajouté avec succès!", Toast.LENGTH_SHORT).show()

                        // Redirection vers la page "Mes Trajets"
                        val intent = Intent(this, DriverActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Erreur lors de l'ajout du trajet: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }
}

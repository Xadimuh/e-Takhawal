package com.example.e_takhawal

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PassengerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_passager)

        // Récupérer le nom d'utilisateur depuis l'intent
        val username = intent.getStringExtra("username") ?: "Utilisateur"

        // Configurer le message de bienvenue
        val welcomeText: TextView = findViewById(R.id.welcome_text_passenger)
        welcomeText.text = "Bonjour, $username !"
    }
}
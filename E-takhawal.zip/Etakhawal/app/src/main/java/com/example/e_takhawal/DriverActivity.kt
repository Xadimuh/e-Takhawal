package com.example.e_takhawal

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class DriverActivity : AppCompatActivity() {

    private lateinit var tripsRecyclerView: RecyclerView
    private lateinit var tripsList: MutableList<Trip>
    private lateinit var tripsAdapter: TripsAdapter
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        // Initialisation des composants
        val welcomeText: TextView = findViewById(R.id.welcome_text_driver)
        val addTripButton: Button = findViewById(R.id.add_trip_button)
        tripsRecyclerView = findViewById(R.id.trips_recycler_view)
        tripsList = mutableListOf()
        tripsAdapter = TripsAdapter(tripsList)

        // Firebase Authentication et Database Reference
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Affichage du nom de l'utilisateur
        val username = intent.getStringExtra("username") ?: "Utilisateur"
        welcomeText.text = "Bonjour, $username !"

        // Configuration du RecyclerView
        tripsRecyclerView.layoutManager = LinearLayoutManager(this)
        tripsRecyclerView.adapter = tripsAdapter

        // Charger les trajets de l'utilisateur
        loadTrips()

        // Redirection vers l'ajout de trajet
        addTripButton.setOnClickListener {
            val intent = Intent(this, AddTripActivity::class.java)
            startActivity(intent)
        }
    }

    // Fonction pour charger les trajets ajoutés par l'utilisateur (conducteur)
    private fun loadTrips() {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            // Charger les trajets du conducteur en filtrant par l'ID de l'utilisateur
            database.child("trips")
                .orderByChild("id")
                .equalTo(userId)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        tripsList.clear()
                        for (dataSnapshot in snapshot.children) {
                            val trip = dataSnapshot.getValue(Trip::class.java)
                            if (trip != null) {
                                tripsList.add(trip)
                            }
                        }
                        tripsAdapter.notifyDataSetChanged()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(this@DriverActivity, "Erreur de chargement des trajets", Toast.LENGTH_SHORT).show()
                    }
                })
        }
    }
}

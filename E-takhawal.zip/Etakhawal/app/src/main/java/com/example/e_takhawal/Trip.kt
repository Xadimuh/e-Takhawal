package com.example.e_takhawal


data class Trip(
    val id: String = "",               // ID unique du trajet
    val source: String = "",           // Source du trajet (ex : "Paris")
    val destination: String = "",      // Destination du trajet (ex : "Lyon")
    val date: String = "",             // Date du trajet (ex : "2025-01-17")
    val time: String = "",             // Heure du trajet (ex : "14:30")
    val status: String = "",           // Statut du trajet (ex : "Disponible", "Réservé", "Terminé")
    val passengerRequest: Boolean = false, // Indique si le passager a fait une demande de réservation
    val driverName: String
)
